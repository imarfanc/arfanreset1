(() => {
  'use strict';
  const pages = [
    ['overview','Overview','◉',''],
    ['clt','Command Line Tools','1','Fresh Mac, in order'],
    ['tools','CLI tools','2',''],
    ['brew','Homebrew','3',''],
    ['defaults','macOS defaults','4',''],
    ['gestures','Trackpad & Accessibility','5',''],
    ['shell','Faster Zsh startup','6',''],
    ['optional','Optional CLI tools','+','Optional & tools'],
    ['disk','Disk usage','◷',''],
    ['guides','Reference guides','▤',''],
  ];
  const $ = id => document.getElementById(id);
  const escape = text => String(text).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  let state = null, page = 'overview', search = '';
  const post = (action, extra = {}) => {
    if (window.webkit?.messageHandlers?.reset1) window.webkit.messageHandlers.reset1.postMessage({action,...extra});
    else notice('This action is available in the native Mac app.');
  };
  function notice(text) { $('toast').textContent = text; $('toast').hidden = false; clearTimeout(notice.timer); notice.timer = setTimeout(() => $('toast').hidden = true, 2600); }
  function button(label, action, extra = {}, primary = false) {
    return `<button ${primary ? 'class="primary"' : ''} data-action="${action}" data-extra="${escape(JSON.stringify(extra))}" ${state.busy ? 'disabled' : ''}>${escape(label)}</button>`;
  }
  function guideLink(file) { return `<button data-guide="${file}">Read original guide</button>`; }
  function title(kicker, heading, description) { return `<p class="eyebrow">${kicker}</p><h1>${heading}</h1><p class="lede">${description}</p>`; }
  function finish(id) { return `<label class="finish"><input type="checkbox" data-complete="${id}" ${state.completed.includes(id) ? 'checked' : ''} ${state.busy ? 'disabled' : ''}>I’ve finished this step on this Mac</label>`; }
  function renderNav() {
    $('nav').innerHTML = pages.map(([id,label,n,group]) => `${group ? `<div class="group">${group}</div>` : ''}<button data-page="${id}" ${page === id ? 'aria-current="page"' : ''}><span class="number ${state.completed.includes(id) ? 'done' : ''}">${state.completed.includes(id) ? '✓' : n}</span>${label}</button>`).join('');
    const done = state.completed.length;
    $('progress-label').textContent = `${done} of 6 setup steps done`;
    $('progress').value = done;
    $('breadcrumb').textContent = pages.find(p => p[0] === page)[1];
    $('activity').textContent = state.busy ? 'Action running…' : 'Ready';
    $('activity').classList.toggle('running', state.busy);
    $('cancel').hidden = !state.busy;
    $('log').textContent = state.log;
  }
  function installers(filter) {
    return state.installers.filter(filter).map(item => `<article class="card"><div class="row"><div class="grow"><h3>${escape(item.name)}</h3><small>${item.optional ? 'Optional · version pinned in your source guide' : 'Official installer from your setup guide'}</small></div>${button('Run in Terminal','installer',{id:item.id})}</div><details><summary>Review installer command</summary><pre class="command">${escape(item.command)}</pre></details></article>`).join('');
  }
  function preferences() {
    const all = state.settings.filter(s => s.section === page);
    const shown = all.filter(s => `${s.group} ${s.description} ${s.key}`.toLowerCase().includes(search.toLowerCase()));
    const groups = [...new Set(shown.map(s => s.group))];
    const count = all.filter(s => state.selected.includes(s.id)).length;
    return title(page === 'defaults' ? 'Step 4 · Swift' : 'Step 5 · Swift', pages.find(p => p[0] === page)[1], page === 'defaults' ? 'Your Finder, Dock, keyboard, windows and screenshot preferences. Select what you want, check the current values, then apply.' : 'Disable the Mission Control swipe, enable trackpad zoom, and turn on the Accessibility Keyboard.') +
      `<div class="actions">${button('Check only','check',{section:page},true)}${button(`Apply ${count} selected`,'apply',{section:page})}${button('Restart Finder & Dock','restart')}</div>` +
      `<p class="note">Apply saves the previous values before writing and verifies each value afterwards. Protected Accessibility settings start unselected; they may need Full Disk Access for <strong>ArfanReset1</strong>. Some changes take effect after logging out.</p>` +
      `<div class="actions">${button('Full Disk Access','settings',{id:'privacy'})}${page === 'gestures' ? button('Zoom settings','settings',{id:'zoom'}) + button('Keyboard settings','settings',{id:'keyboard'}) : ''}${guideLink(page === 'defaults' ? 'setup-defaults.html' : 'setup-defaults2.html')}</div>` +
      `<div class="toolbar"><input type="search" id="search" aria-label="Filter preferences" placeholder="Find a preference…" value="${escape(search)}"><button data-selection="all" ${state.busy ? 'disabled' : ''}>Select visible</button><button data-selection="none" ${state.busy ? 'disabled' : ''}>Deselect visible</button><small>${count} selected</small></div>` +
      (groups.length ? groups.map(group => `<h2>${escape(group)}</h2><div class="settings-group">${shown.filter(s => s.group === group).map(s => `<label class="setting"><input type="checkbox" data-setting="${s.id}" ${state.selected.includes(s.id) ? 'checked' : ''} ${state.busy ? 'disabled' : ''}><span class="text"><strong>${escape(s.description)}${s.domain === 'com.apple.universalaccess' ? '<span class="badge">Protected</span>' : ''}</strong><small>${escape(s.domain)} · ${escape(s.key)}${s.currentHost ? ' · this Mac' : ''}</small></span><span class="value">${escape(s.value)}</span></label>`).join('')}</div>`).join('') : '<p class="empty">No matching preferences.</p>') +
      `<div class="actions">${state.hasBackup ? button('Restore last preference backup','restore') : ''}${button('Show backups & logs','reveal')}</div>` + finish(page);
  }
  function renderMain() {
    if (!state) return;
    let html = '';
    if (page === 'overview') {
      const next = pages.find(([id]) => ['clt','tools','brew','defaults','gestures','shell'].includes(id) && !state.completed.includes(id));
      html = title('New Mac · after a reset', 'Make this Mac yours.', 'Start with the tools, then your preferences. Everything here is bundled with the app; choose the actions you want to run.') +
        `<p class="subtle">${escape(state.system)}</p><div class="card"><div class="row"><div class="grow"><h3>${next ? 'Next up: ' + escape(next[1]) : 'Your checklist is complete'}</h3><p>${next ? 'Go at your own pace. Each step has its own actions and guide.' : 'You can revisit any step or check the current setup.'}</p></div>${next ? `<button class="primary" data-page="${next[0]}">Continue →</button>` : ''}</div></div>` +
        pages.filter(([, ,n]) => /^[1-6]$/.test(n)).map(([id,label,n]) => `<div class="card row step ${state.completed.includes(id) ? 'done' : ''}"><span class="step-num">${state.completed.includes(id) ? '✓' : n}</span><div class="grow"><strong>${label}</strong><small>${({clt:'Apple’s developer tools: Git, clang and make.',tools:'Deno, uv, Atuin, AI tools, Node and Bun.',brew:'Homebrew and its shell PATH.',defaults:'Choose and apply your everyday Mac preferences.',gestures:'Mission Control, zoom and Accessibility Keyboard.',shell:'Back up .zshrc and defer heavy startup work.'})[id]}</small></div><button data-page="${id}">Open</button></div>`).join('') +
        `<div class="actions">${button('Check this Mac','tools',{},true)}${button('Show backups & logs','reveal')}</div><p class="subtle">The app itself needs no uv, Deno, Homebrew, Python or Xcode. Swift handles the local setup actions. Installers use the internet and may ask for your password in Terminal.</p>`;
    } else if (page === 'clt') {
      html = title('Step 1 · Apple tools','Command Line Tools','Install Git, clang, make and the macOS SDK through Apple’s installer.') + `<div class="card"><h3>Start with Apple’s installer</h3><p>Open the installation dialog, complete its prompts, then check this Mac. Installing developer tools is optional for the native setup features.</p><div class="actions">${button('Install Command Line Tools','clt',{},true)}${button('Check this Mac','tools')}</div><pre class="command">xcode-select --install</pre></div><div class="card"><h3>Prefer the Software Update script?</h3><p>The original guide includes a Terminal script that finds the newest available package and installs it with sudo.</p>${guideLink('install-command-line-tools.html')}</div>` + finish('clt');
    } else if (page === 'tools' || page === 'optional') {
      html = title(page === 'tools' ? 'Step 2 · Install what you use' : 'Optional · Developer tools', page === 'tools' ? 'CLI tools' : 'Optional CLI tools', 'Review a command, then run its installer in Terminal. Finish any prompts there and return here to check the result.') + `<div class="actions">${button('Check this Mac','tools',{},true)}${guideLink(page === 'tools' ? 'install-cli-tools.html' : 'optional-cli-tools.html')}</div>` + (page === 'optional' ? '<p class="note">Go and Zig use the Apple Silicon versions pinned in your original guide. Review those versions for the project you’re building. Ghostty build instructions are in Reference guides.</p>' : '') + installers(i => i.id !== 'install' && i.optional === (page === 'optional')) + (page === 'tools' ? finish('tools') : '');
    } else if (page === 'brew') {
      html = title('Step 3 · Package manager','Homebrew','Use the official installer, then add brew to your login shell PATH.') + '<p class="note">Install Command Line Tools first. This installer uses Terminal for password prompts and detects the Apple Silicon or Intel install location.</p>' + installers(i => i.id === 'install') + `<div class="actions">${button('Check this Mac','tools')}${guideLink('install-homebrew.html')}</div>` + finish('brew');
    } else if (page === 'defaults' || page === 'gestures') html = preferences();
    else if (page === 'shell') {
      html = title('Step 6 · Swift','Faster Zsh startup','Keep tool paths ready, then load nvm and completions on first use. Your existing configuration is backed up before a change.') + `<div class="card"><h3>Your shell configuration</h3><p><code>${escape(state.shellPath)}</code></p><div class="actions">${button('Check & preview','shellCheck',{},true)}${button('Set up Zsh','shellApply')}${button('Choose ZDOTDIR folder','shellFolder')}</div></div><div class="card"><h3>What this changes</h3><p>Updates one marked section, disables recognized eager loader lines, keeps unrelated configuration, and validates the result with <code>zsh -n</code>. Rerunning the same setup creates no extra backup.</p><p>Backups live in the <code>backups</code> folder beside your .zshrc. The run log prints the exact path. Restore that file if needed, then open a new Terminal.</p><p>Custom frameworks, multiline loaders and plugins stay in place. First Tab and first Node command pay the deferred initialization cost.</p></div><div class="actions">${guideLink('setup-zsh.html')}${button('Check this Mac','tools')}</div>` + finish('shell');
    } else if (page === 'disk') {
      html = title('Tool · Swift + macOS du','Disk usage','See the largest folders in your home directory. The scan is read only and does not need Python, uv or Rich.') + `<div class="card"><h3>Scan your home folder</h3><p>This can take a minute or two. Protected folders can produce a partial result; Full Disk Access lets the app see more.</p><div class="actions">${button('Scan home folder','disk',{},true)}${button('Storage settings','settings',{id:'storage'})}${button('Full Disk Access','settings',{id:'privacy'})}</div></div><h2>Original scans</h2><p>The source guides also include the detailed Rich reports.</p><div class="actions">${guideLink('disk-usage.html')}${guideLink('disk-usage-macos.html')}</div>`;
    } else if (page === 'guides') {
      html = title('Offline · Original reference','Reference guides','All ten pages from your macOS reset1 guide, with their scripts embedded. Links and installers still need internet access.') + state.guides.map(g => `<div class="card row"><div class="grow"><strong>${escape(g.title)}</strong></div><button data-guide="${g.file}">Read guide</button></div>`).join('') + '<p class="subtle">Bundled snapshot: October 2, 2026. These guides preserve the source instructions and pinned versions. Native actions use the simpler workflows on the setup pages.</p>';
    }
    $('main').innerHTML = html;
  }
  function showPage(id) {
    if (!pages.some(p => p[0] === id)) return;
    page = id; search = ''; renderNav(); renderMain(); $('main').scrollTop = 0; $('main').focus({preventScroll:true});
  }
  window.receive = payload => {
    if (payload.type === 'notice') { notice(payload.text); return; }
    if (payload.type !== 'state') return;
    const focused = document.activeElement;
    const setting = focused?.dataset?.setting;
    const cursor = focused?.id === 'search' ? focused.selectionStart : null;
    const scroll = $('main').scrollTop;
    state = payload; renderNav(); renderMain(); $('main').scrollTop = scroll;
    if (cursor !== null && $('search')) { $('search').focus(); $('search').setSelectionRange(cursor,cursor); }
    if (setting) document.querySelector(`[data-setting="${setting}"]`)?.focus({preventScroll:true});
  };
  document.addEventListener('click', event => {
    const node = event.target.closest('button'); if (!node || node.disabled) return;
    if (node.dataset.page) showPage(node.dataset.page);
    if (node.dataset.action) post(node.dataset.action,JSON.parse(node.dataset.extra || '{}'));
    if (node.dataset.guide) {
      $('guide-title').textContent = state.guides.find(g => g.file === node.dataset.guide)?.title || 'Reference guide';
      $('guide-frame').src = 'guides/' + node.dataset.guide; $('guide').showModal();
    }
    if (node.dataset.selection) {
      const ids = new Set(state.selected);
      document.querySelectorAll('[data-setting]').forEach(input => node.dataset.selection === 'all' ? ids.add(input.dataset.setting) : ids.delete(input.dataset.setting));
      post('select',{ids:[...ids]});
    }
  });
  document.addEventListener('change', event => {
    const target = event.target;
    if (target.dataset.setting) {
      const ids = new Set(state.selected); target.checked ? ids.add(target.dataset.setting) : ids.delete(target.dataset.setting); post('select',{ids:[...ids]});
    }
    if (target.dataset.complete) post('complete',{id:target.dataset.complete,value:target.checked});
  });
  document.addEventListener('input', event => {
    if (event.target.id !== 'search') return;
    const cursor = event.target.selectionStart; search = event.target.value; renderMain(); $('search').focus(); $('search').setSelectionRange(cursor,cursor);
  });
  $('close-guide').addEventListener('click', () => $('guide').close());
  $('cancel').addEventListener('click', () => post('cancel'));
  $('copy-log').addEventListener('click', () => post('copyLog'));
  $('toggle-log').addEventListener('click', () => {
    $('log').hidden = !$('log').hidden; $('toggle-log').textContent = $('log').hidden ? 'Show' : 'Hide'; $('toggle-log').setAttribute('aria-expanded',String(!$('log').hidden));
  });
  post('ready');
})();
