repos2() {
  uv run --with rich --quiet ~/Documents/GitHub/t1/scripts/repos.py --root ~/Documents/GitHub "$@"
}
