// A workspace holds terminals, a terminal holds tabs, and each tab runs one shell. See NOMENCLATURE.md.
(() => {
  'use strict';
  const $ = id => document.getElementById(id);
  const post = (action, extra = {}) => window.webkit?.messageHandlers.cmux2.postMessage({action, ...extra});
  const element = (tag, className = '', text = '') => { const node = document.createElement(tag); node.className = className; node.textContent = text; return node; };
  const plural = (count, word) => `${count} ${word}${count === 1 ? '' : 's'}`;
  const text = (value, limit) => typeof value === 'string' ? value.trim().slice(0, limit) : '';
  const list = value => Array.isArray(value) ? value : [];
  // An icon is the name of a drawing in vendor/icons.js, else one or two characters shown as text.
  const icons = window.cmuxIcons || {}, drawn = icon => Object.hasOwn(icons, icon);
  function draw(node, icon) {
    if (drawn(icon)) node.innerHTML = `<svg class="icon" viewBox="0 0 24 24" aria-hidden="true">${icons[icon]}</svg>`; else node.textContent = icon;
    // A drawing or a lone symbol is shown larger than a two-letter icon so all fill their button alike.
    node.classList.toggle('glyph', drawn(icon) || [...icon].length === 1);
    return node;
  }
  // Each theme's colours and layout are in themes.css.
  const themes = [{id: 'brew', name: 'Brew Hub'}, {id: 'jasmine', name: 'Jasmine'}, {id: 'slate', name: 'Slate'}];
  // A tab that does not wrap its lines is at least this many columns wide, and scrolls sideways.
  const wide = 240;
  const workspaces = new Map(), terminals = new Map(), tabs = new Map();
  let presets = [], active = null, current = null, sidebarHidden = false, fontSize = 14, lineHeight = 1, shell = 'shell';
  let history = [], historyIndex = -1, copied = 0;
  // Nothing is saved until last time's workspaces are open again, and while they open their tabs' commands are not run again.
  let restored = false, restoring = false;
  const made = {tab: 0, terminal: 0, workspace: 0}, identifier = kind => kind + '-' + ++made[kind];
  const dark = matchMedia('(prefers-color-scheme: dark)');
  const ansi = ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'];
  const themed = name => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
  function colors() {
    const result = {background: '#00000000', foreground: themed('--term-foreground'), cursor: themed('--term-cursor'), selectionBackground: themed('--term-selection')};
    ansi.forEach((name, i) => { result[name] = themed('--ansi-' + i); result['bright' + name[0].toUpperCase() + name.slice(1)] = themed('--ansi-' + (i + 8)); });
    return result;
  }
  // How every terminal looks: the theme's colours and cursor, and the text settings.
  const look = () => ({theme: colors(), cursorStyle: themed('--term-cursor-style') || 'bar', fontSize, lineHeight});
  const atEnd = tab => tab.term.buffer.active.viewportY >= tab.term.buffer.active.baseY;
  // Also run when macOS switches between light and dark, since each theme has both.
  function retheme() {
    // Rows of another height can leave xterm a few rows above the end of its screen, so a tab showing its end is put back there once refitted.
    const ended = [...tabs.values()].filter(atEnd);
    for (const tab of tabs.values()) Object.assign(tab.term.options, look());
    post('windowColor', {color: themed('--bg')});
    requestAnimationFrame(() => { fitActive(); requestAnimationFrame(() => { for (const tab of ended) if (tabs.has(tab.id)) tab.term.scrollToBottom(); }); });
  }
  function applyTheme(id) {
    const chosen = themes.some(item => item.id === id) ? id : themes[0].id;
    document.documentElement.dataset.theme = chosen;
    for (const button of $('themes').children) button.setAttribute('aria-pressed', button.dataset.themeId === chosen);
    retheme();
  }
  // The tab on stage is drawn on a canvas, where xterm draws block and box characters itself so they meet from cell to cell
  // instead of leaving the gaps a font's own leave. The other tabs keep xterm's lighter drawing: a canvas each would be costly.
  function paint(tab, staged) {
    if (staged && !tab.canvas) { tab.canvas = new CanvasAddon.CanvasAddon(); tab.term.loadAddon(tab.canvas); }
    if (!staged && tab.canvas) { tab.canvas.dispose(); tab.canvas = null; }
  }
  function fitTab(tab) {
    if (tab.wrap) { tab.fit.fit(); return; }
    const size = tab.fit.proposeDimensions();
    if (size?.cols && size.rows) tab.term.resize(Math.max(size.cols, wide), size.rows);
  }
  function fitActive() {
    const tab = tabs.get(active);
    if (tab) { fitTab(tab); tab.term.focus(); }
  }
  // Brings the cursor back on screen in a tab that scrolls sideways.
  function follow(tab) {
    const pane = tab.pane, screen = tab.term.element, cell = screen.querySelector('.xterm-screen').offsetWidth / tab.term.cols;
    const cursor = screen.offsetLeft + tab.term.buffer.active.cursorX * cell, margin = 4 * cell;
    if (cursor - margin < pane.scrollLeft) pane.scrollLeft = cursor - margin;
    else if (cursor + margin > pane.scrollLeft + pane.clientWidth) pane.scrollLeft = cursor + margin - pane.clientWidth;
  }
  // Everything a tab has printed, scrollback included, with wrapped lines joined again.
  function contents(term) {
    const buffer = term.buffer.active, lines = [];
    for (let i = 0; i < buffer.length; i++) {
      const line = buffer.getLine(i), part = line.translateToString(true);
      if (line.isWrapped && lines.length) lines[lines.length - 1] += part; else lines.push(part);
    }
    return lines.join('\n').trimEnd();
  }
  function updateNavigation() {
    document.documentElement.classList.toggle('sidebar-hidden', sidebarHidden);
    post('navigationState', {sidebarHidden, back: historyIndex > 0, forward: historyIndex < history.length - 1, tab: tabs.has(active)});
  }
  // The tab a workspace or terminal shows when it is chosen: the one last on stage in it.
  const lastTab = owner => owner?.terminals ? terminals.get(owner.last)?.last : owner?.last;
  function iconButton(className, icon, name, select) {
    const button = draw(element('button', className), icon);
    button.title = name; button.setAttribute('aria-label', name); button.onclick = select;
    return button;
  }
  function row(className, icon, name, detail, select) {
    const item = element('div', 'item ' + className), button = element('button', 'item-select'), copy = element('span', 'item-copy');
    const mark = draw(element('span', 'item-icon'), icon); mark.setAttribute('aria-hidden', 'true');
    copy.append(element('strong', '', name), element('small', '', detail)); button.append(mark, copy); button.onclick = select;
    item.append(button); return item;
  }
  // A workspace written the way a preset is. `id` lets the app look up the folder each tab's shell is in now.
  const describe = workspace => ({name: workspace.name, icon: workspace.icon, directory: workspace.directory, count: workspace.count, terminals: workspace.terminals.map(id => {
    const terminal = terminals.get(id);
    return {name: terminal.name, directory: terminal.directory, tabs: terminal.tabs.map(id => { const tab = tabs.get(id); return {id, title: tab.named ? tab.title : '', directory: tab.directory, command: tab.command}; })};
  })});
  // What to open again next time: every workspace, and where on stage the app was (workspace, terminal and tab, counted from 0).
  function layout() {
    const shown = tabs.get(active) || tabs.get(lastTab(workspaces.get(current))), terminal = shown?.terminal;
    return {workspaces: [...workspaces.values()].map(describe), number: made.workspace,
      stage: shown ? [[...workspaces.keys()].indexOf(terminal.workspace.id), terminal.workspace.terminals.indexOf(terminal.id), terminal.tabs.indexOf(shown.id)] : []};
  }
  // A preset, or a workspace saved last time, as the page uses it. Anything missing gets a default; a terminal without tabs is dropped.
  const clean = (preset, most = 12) => ({
    name: text(preset.name, 60), icon: (icon => icon.length > 2 && drawn(icon) ? icon : [...icon].slice(0, 2).join(''))(text(preset.icon, 40)) || text(preset.name, 60).slice(0, 1).toUpperCase(), directory: text(preset.directory, 1000) || '~', count: Math.min(9999, Number(preset.count) || 0),
    terminals: list(preset.terminals).slice(0, most).map((terminal, index) => ({
      name: text(terminal.name, 60) || 'Terminal ' + (index + 1), directory: text(terminal.directory, 1000),
      tabs: list(terminal.tabs).slice(0, most).map(tab => ({title: text(tab.title, 60), directory: text(tab.directory, 1000), command: text(tab.command, 2000)})),
    })).filter(terminal => terminal.tabs.length),
  });
  const usable = preset => preset.name && preset.terminals.length;
  function render() {
    const tab = tabs.get(active), terminal = tab?.terminal, workspace = terminal?.workspace || workspaces.get(current), settings = active === 'settings';
    let running = 0;
    for (const item of tabs.values()) if (!item.exited) running++;
    $('workspaces').replaceChildren();
    for (const entry of workspaces.values()) {
      const button = iconButton('workspace' + (entry === workspace ? ' selected' : ''), entry.icon, entry.name, () => activate(lastTab(entry)));
      button.dataset.workspace = entry.id; button.setAttribute('aria-current', entry === workspace ? 'page' : 'false');
      $('workspaces').append(button);
    }
    $('workspaces').append(iconButton('workspace add', 'plus', 'New workspace (⇧⌘N)', () => createWorkspace()));
    if (workspace) $('workspaces').append(iconButton('workspace close', 'x', 'Close ' + workspace.name + ' (middle-click closes every workspace)', () => closeWorkspace(workspace.id)));
    $('terminals').replaceChildren();
    for (const id of workspace?.terminals || []) {
      const entry = terminals.get(id), live = entry.tabs.some(item => !tabs.get(item).exited);
      const item = row((entry === terminal ? 'selected' : '') + (live ? '' : ' exited'), 'terminal', entry.name, live ? plural(entry.tabs.length, 'tab') : 'Session ended', () => activate(entry.last));
      item.dataset.terminal = id; item.firstChild.setAttribute('aria-current', entry === terminal ? 'page' : 'false');
      const close = draw(element('button', 'item-close'), 'x'); close.setAttribute('aria-label', 'Close ' + entry.name); close.onclick = () => closeTerminal(id);
      item.append(close); $('terminals').append(item);
    }
    $('tabs').replaceChildren();
    for (const id of terminal?.tabs || []) {
      const entry = tabs.get(id), pill = element('div', 'tab' + (id === active ? ' selected' : '') + (entry.exited ? ' exited' : '')); pill.dataset.id = id;
      const select = element('button', 'tab-select'); select.append(element('span', '', entry.title)); select.setAttribute('aria-current', id === active ? 'page' : 'false'); select.onclick = () => activate(id);
      const close = draw(element('button', 'tab-close'), 'x'); close.setAttribute('aria-label', 'Close ' + entry.title); close.onclick = () => closeTab(id);
      pill.append(select, close); $('tabs').append(pill);
    }
    $('terminals-label').textContent = workspace ? workspace.name : 'Terminals';
    $('count').textContent = workspace ? workspace.terminals.length : 0;
    $('terminals').hidden = !workspace;
    $('no-terminals').hidden = !!workspace;
    $('tabbar').hidden = !terminal;
    $('wrap-lines').setAttribute('aria-pressed', tab ? tab.wrap : true);
    $('empty').hidden = workspaces.size > 0 || settings;
    $('settings').hidden = !settings;
    $('session-count').textContent = running ? plural(running, 'active session') : 'No active sessions';
    $('breadcrumb').replaceChildren(...(settings ? ['Settings'] : terminal ? [element('span', 'crumb', workspace.name), terminal.name] : ['cmux2']));
    $('activity').textContent = settings ? '' : tab ? tab.exited ? 'Session ended' : tab.directory : 'Ready';
    // With a tab on stage the app shows its open-in buttons at the end of the titlebar, and the folder stops short of them. In full screen they are away.
    $('header').style.paddingRight = tab ? 'calc(var(--chrome-tools, 14px) + 8px)' : '';
    $('shell-label').textContent = shell;
    const hints = settings ? [['esc', 'Back']] : tab ? [['⌘T', 'New tab'], ['⌘W', 'Close tab']] : [['⌘N', 'New terminal']];
    $('hint').replaceChildren(...hints.map(([key, label]) => { const hint = element('span', 'key'); hint.append(element('kbd', '', key), label); return hint; }));
    $('dimensions').textContent = tab ? `${tab.term.cols} × ${tab.term.rows}` : '';
    if (restored) post('layout', layout());
  }
  function renderPresets() {
    $('presets').replaceChildren(); $('empty-presets').replaceChildren();
    for (const preset of presets) {
      const item = row('preset', preset.icon, preset.name, plural(preset.terminals.length, 'terminal') + ' · ' + preset.directory, () => createWorkspace(preset));
      item.firstChild.title = 'Open ' + preset.name; $('presets').append(item);
      const button = element('button', '', preset.name); button.onclick = () => createWorkspace(preset); $('empty-presets').append(button);
    }
    $('preset-block').hidden = presets.length === 0;
  }
  // Tabs and Settings are the pages that can take the stage; each has its place in the Back/Forward history.
  function activate(id, remember = true) {
    const tab = tabs.get(id);
    if (id !== 'settings' && !tab) return;
    active = id;
    if (tab) { tab.terminal.last = id; tab.terminal.workspace.last = tab.terminal.id; current = tab.terminal.workspace.id; }
    for (const item of tabs.values()) { item.pane.hidden = item.id !== id; paint(item, item.id === id); }
    if (remember && history[historyIndex] !== id) { history = history.slice(0, historyIndex + 1); history.push(id); historyIndex = history.length - 1; }
    render(); updateNavigation(); requestAnimationFrame(fitActive);
    if (tab) post('where', {id});
  }
  function createTab(terminal, spec = {}, remember = true) {
    if (tabs.size >= 32) { notice('Close a tab before opening another (32 tabs maximum).'); return null; }
    const id = identifier('tab'), number = ++terminal.count, fallback = number === 1 ? shell : shell + ' ' + number;
    const pane = element('div', 'pane'); $('panes').append(pane);
    const term = new Terminal({fontFamily: "Menlo, 'cmux2 Symbols', monospace", cursorBlink: true, scrollback: 10000, allowTransparency: true, screenReaderMode: true, ...look()});
    const fit = new FitAddon.FitAddon(); term.loadAddon(fit); term.open(pane);
    // A title given by a preset stays; otherwise the tab follows the title its shell or program sets.
    const tab = {id, terminal, title: spec.title || fallback, named: !!spec.title, directory: spec.directory || terminal.directory, command: spec.command || '', pane, term, fit, canvas: null, exited: false, wrap: true, typed: 0};
    tabs.set(id, tab); terminal.tabs.push(id);
    // A command may have moved the shell to another folder, so the app is asked where it is once the command has had a moment.
    term.onData(data => { tab.typed = performance.now(); if (!tab.exited) post('input', {id, data}); if (data.includes('\r')) setTimeout(() => post('where', {id}), 300); });
    // Only the echo of typing moves the view sideways, so other output does not pull it away from what is being read.
    term.onCursorMove(() => { if (!tab.wrap && performance.now() - tab.typed < 500) follow(tab); });
    // xterm scrolls up and down only, so a sideways swipe is taken here before it reaches xterm.
    pane.addEventListener('wheel', event => { if (!tab.wrap && Math.abs(event.deltaX) > Math.abs(event.deltaY)) { event.preventDefault(); event.stopPropagation(); pane.scrollLeft += event.deltaX; } }, {capture: true, passive: false});
    term.onResize(({cols, rows}) => { post('resize', {id, columns: cols, rows}); if (id === active) $('dimensions').textContent = `${cols} × ${rows}`; });
    term.onTitleChange(title => { if (!tab.named) { tab.title = title.slice(0, 120).trim() || fallback; render(); } });
    term.attachCustomKeyEventHandler(event => !((event.metaKey && (/^Digit[1-9]$/.test(event.code) || ['t','n','w','b',',','c','v','a','h','m','=','+','-'].includes(event.key.toLowerCase()))) || (event.ctrlKey && event.key === 'Tab')));
    activate(id, remember); fitTab(tab); post('create', {id, columns: term.cols, rows: term.rows, directory: tab.directory, command: restoring ? '' : tab.command}); term.focus();
    return tab;
  }
  // Without a spec: one tab in the workspace's folder. Returns nothing when no tab could be opened.
  function createTerminal(workspace, spec, remember = true) {
    const terminal = {id: identifier('terminal'), workspace, name: spec?.name || 'Terminal ' + ++workspace.count, directory: spec?.directory || workspace.directory, tabs: [], last: null, count: 0};
    terminals.set(terminal.id, terminal); workspace.terminals.push(terminal.id);
    for (const tab of spec?.tabs || [{}]) if (!createTab(terminal, tab, false)) break;
    if (!terminal.tabs.length) { terminals.delete(terminal.id); workspace.terminals.pop(); return null; }
    if (remember) activate(terminal.tabs[0]);
    return terminal;
  }
  // Without a preset: one terminal in the home folder, with the workspace's number as its icon.
  function createWorkspace(preset) {
    const id = identifier('workspace'), number = made.workspace;
    const workspace = {id, name: preset?.name || 'Workspace ' + number, icon: preset?.icon || String(number), directory: preset?.directory || '~', terminals: [], last: null, count: preset?.count || 0};
    workspaces.set(workspace.id, workspace);
    for (const spec of preset?.terminals || [null]) if (!createTerminal(workspace, spec, false)) break;
    if (workspace.terminals.length) activate(terminals.get(workspace.terminals[0]).tabs[0]); else workspaces.delete(workspace.id);
  }
  // A terminal closes with its last tab, and a workspace with its last terminal.
  function closeTab(id) {
    const tab = tabs.get(id); if (!tab) return;
    const terminal = tab.terminal, workspace = terminal.workspace;
    const beside = (ids, gone) => { const index = ids.indexOf(gone); return ids[index + 1] || ids[index - 1]; };
    // Where the stage goes if this tab is on it: the next tab, else the next terminal, else the next workspace.
    const next = beside(terminal.tabs, id) || lastTab(terminals.get(beside(workspace.terminals, terminal.id))) || lastTab(workspaces.get(beside([...workspaces.keys()], workspace.id)));
    // The canvas goes first: disposed along with its terminal, it fails trying to hand the drawing back to it.
    post('close', {id}); paint(tab, false); tab.term.dispose(); tab.pane.remove(); tabs.delete(id); forget(id);
    terminal.tabs.splice(terminal.tabs.indexOf(id), 1);
    if (terminal.last === id) terminal.last = terminal.tabs[0] || null;
    if (!terminal.tabs.length) {
      terminals.delete(terminal.id); workspace.terminals.splice(workspace.terminals.indexOf(terminal.id), 1);
      if (workspace.last === terminal.id) workspace.last = workspace.terminals[0] || null;
      if (!workspace.terminals.length) { workspaces.delete(workspace.id); if (current === workspace.id) current = workspaces.keys().next().value || null; }
    }
    if (active === id) { active = null; if (next) activate(next); }
    render(); updateNavigation();
  }
  // The tab on stage goes last, so the stage changes once.
  const closeTabs = ids => { for (const id of [...ids].sort((a, b) => (a === active) - (b === active))) closeTab(id); };
  const closeTerminal = id => closeTabs(terminals.get(id)?.tabs || []);
  const closeWorkspace = id => closeTabs((workspaces.get(id)?.terminals || []).flatMap(item => terminals.get(item).tabs));
  // Forget a closed page without leaving the same page twice in a row or moving the cursor off its entry.
  function forget(id) {
    const kept = []; let cursor = -1;
    history.forEach((value, i) => { if (value !== id && value !== kept[kept.length - 1]) kept.push(value); if (i === historyIndex) cursor = kept.length - 1; });
    history = kept; historyIndex = cursor;
  }
  function closeSettings() {
    if (active !== 'settings') return;
    forget('settings'); active = null;
    const next = history[historyIndex] || lastTab(workspaces.get(current));
    if (next) activate(next); else { render(); updateNavigation(); }
  }
  function notice(text) { $('notice').textContent = text; $('notice').hidden = false; clearTimeout(notice.timer); notice.timer = setTimeout(() => { $('notice').hidden = true; }, 6000); }
  // `id` is a tab, terminal or workspace; without one the action applies to what is on stage.
  window.cmuxAction = (action, id = active) => {
    if (action === 'closeTab' && id === 'settings') { closeSettings(); return; }
    const tab = tabs.get(id), terminal = terminals.get(id) || tab?.terminal || terminals.get(workspaces.get(current)?.last);
    const workspace = workspaces.get(id) || terminal?.workspace || workspaces.get(current);
    if (action === 'newTab') { if (terminal) createTab(terminal); else if (workspace) createTerminal(workspace); else createWorkspace(); }
    if (action === 'newTerminal') { if (workspace) createTerminal(workspace); else createWorkspace(); }
    if (action === 'newWorkspace') createWorkspace();
    if (action === 'closeTab') closeTab(id);
    if (action === 'closeOtherTabs' && tab) closeTabs(tab.terminal.tabs.filter(other => other !== id));
    if (action === 'closeTerminal' && terminal) closeTerminal(terminal.id);
    if (action === 'closeOtherTerminals' && terminal) for (const other of [...terminal.workspace.terminals]) if (other !== terminal.id) closeTerminal(other);
    if (action === 'closeWorkspace' && workspace) closeWorkspace(workspace.id);
    if (action === 'closeOtherWorkspaces' && workspace) for (const other of [...workspaces.keys()]) if (other !== workspace.id) closeWorkspace(other);
    if (action === 'sidebar') { sidebarHidden = !sidebarHidden; post('sidebar', {hidden: sidebarHidden}); updateNavigation(); requestAnimationFrame(fitActive); }
    if (action === 'settings') { if (active === 'settings') closeSettings(); else activate('settings'); }
    if (action === 'back' && historyIndex > 0) activate(history[--historyIndex], false);
    if (action === 'forward' && historyIndex < history.length - 1) activate(history[++historyIndex], false);
    if (action === 'copy') post('clipboard', {text: tab?.term.getSelection() || ''});
    if (action === 'copyTab' && tab) { post('clipboard', {text: contents(tab.term)}); $('copy-tab').classList.add('done'); clearTimeout(copied); copied = setTimeout(() => $('copy-tab').classList.remove('done'), 1200); }
    if (action === 'wrap' && tab) { tab.wrap = !tab.wrap; tab.pane.classList.toggle('nowrap', !tab.wrap); tab.pane.scrollLeft = 0; fitTab(tab); render(); }
    if (action === 'paste' && tab) post('paste', {id});
    if (action === 'selectAll') tab?.term.selectAll();
    if (action === 'clear') tab?.term.clear();
    // openFinder, openCursor, openTerminal: the app opens the folder the tab's shell is in.
    if (action.startsWith('open') && tab) post('open', {id: tab.id, app: action.slice(4), directory: tab.directory});
  };
  window.receive = message => {
    const tab = tabs.get(message.id);
    if (message.type === 'chrome') {
      document.documentElement.classList.toggle('fullscreen', message.fullScreen);
      if (!message.fullScreen) for (const edge of ['left', 'top', 'width', 'height', 'tools']) document.documentElement.style.setProperty('--chrome-' + edge, message[edge] + 'px');
      else document.documentElement.style.removeProperty('--chrome-tools');
    }
    if (message.type === 'output' && tab) { const bytes = Uint8Array.from(atob(message.data), value => value.charCodeAt(0)); tab.term.write(bytes, () => post('drawn', {id: tab.id, count: bytes.length})); }
    if (message.type === 'paste' && tab && !tab.exited) tab.term.paste(message.text);
    if (message.type === 'exit' && tab) { tab.exited = true; tab.term.write('\r\n\x1b[2m[Session ended]\x1b[0m\r\n'); render(); }
    if (message.type === 'error') { if (tab) { tab.exited = true; tab.term.writeln(message.text); render(); } notice(message.text); }
    if (message.type === 'notice') notice(message.text);
    if (message.type === 'directory' && tab && tab.directory !== message.directory) { tab.directory = message.directory; render(); }
    if (message.type === 'presets') {
      presets = list(message.presets).map(preset => clean(preset)).filter(usable);
      renderPresets(); if (message.problem) notice(message.problem);
    }
    // The workspaces that were open when the app last closed. Every tab is a new shell in the folder its old one was in.
    if (message.type === 'layout') {
      restoring = true;
      for (const saved of list(message.workspaces).map(saved => clean(saved, 32)).filter(usable)) createWorkspace(saved);
      restoring = false;
      // New workspaces carry on from the last number given out.
      made.workspace = Math.max(made.workspace, Number(message.number) || 0);
      const [workspace, terminal, tab] = list(message.stage), staged = terminals.get([...workspaces.values()][workspace]?.terminals[terminal])?.tabs[tab];
      history = []; historyIndex = -1; activate(staged || active);
      restored = true; render();
    }
    if (message.type === 'appearance') {
      sidebarHidden = message.sidebarHidden; fontSize = message.fontSize; lineHeight = message.lineHeight; shell = message.shell;
      if ('background' in message) { $('background').hidden = !message.background; if (message.background) $('background').src = message.background; }
      $('background-source').textContent = message.backgroundSource;
      document.documentElement.style.setProperty('--overlay', message.opacity + '%');
      document.documentElement.style.setProperty('--rail-overlay', Math.min(100, message.opacity + 12) + '%');
      $('opacity').value = message.opacity; $('opacity-value').textContent = message.opacity + '%';
      $('font-size').value = fontSize; $('font-value').textContent = fontSize + ' px';
      $('line-height').value = lineHeight; $('line-value').textContent = lineHeight.toFixed(2);
      applyTheme(message.theme); render(); updateNavigation();
    }
  };
  for (const {id, name} of themes) {
    const button = element('button', 'theme'), swatch = element('span', 'swatch');
    button.dataset.themeId = id; swatch.dataset.theme = id; button.append(swatch, name);
    button.onclick = () => { applyTheme(id); post('theme', {value: id}); };
    $('themes').append(button);
  }
  for (const node of document.querySelectorAll('[data-icon]')) draw(node, node.dataset.icon);
  $('first-workspace').onclick = () => createWorkspace();
  $('new-tab').onclick = () => window.cmuxAction('newTab');
  $('new-terminal').onclick = () => window.cmuxAction('newTerminal');
  $('save-preset').onclick = () => { const workspace = workspaces.get(current); if (workspace) post('savePreset', {preset: describe(workspace)}); else notice('Open a workspace first: + saves the one you are in as a preset.'); };
  // The keyboard goes back to the screen, so typing carries on after a click.
  for (const [id, action] of [['wrap-lines', 'wrap'], ['copy-tab', 'copyTab']]) $(id).onclick = () => { window.cmuxAction(action); tabs.get(active)?.term.focus(); };
  $('close-settings').onclick = closeSettings;
  $('choose-background').onclick = () => post('backgroundFile');
  $('default-background').onclick = () => post('backgroundDefault');
  $('clear-background').onclick = () => post('backgroundClear');
  $('opacity').oninput = () => { const opacity = Number($('opacity').value); $('opacity-value').textContent = opacity + '%'; document.documentElement.style.setProperty('--overlay', opacity + '%'); document.documentElement.style.setProperty('--rail-overlay', Math.min(100, opacity + 12) + '%'); };
  $('opacity').onchange = () => post('opacity', {value: Number($('opacity').value)});
  $('font-size').oninput = () => { $('font-value').textContent = $('font-size').value + ' px'; };
  $('font-size').onchange = () => post('fontSize', {value: Number($('font-size').value)});
  $('line-height').oninput = () => { $('line-value').textContent = Number($('line-height').value).toFixed(2); };
  $('line-height').onchange = () => post('lineHeight', {value: Number($('line-height').value)});
  // The menu itself is native: the page only reports what was clicked.
  document.addEventListener('contextmenu', event => {
    event.preventDefault();
    const pill = event.target.closest('.tab'), pane = event.target.closest('.pane'), item = event.target.closest('[data-terminal]'), icon = event.target.closest('[data-workspace]');
    const tab = tabs.get(pill ? pill.dataset.id : pane ? active : null), terminal = tab?.terminal || terminals.get(item?.dataset.terminal);
    post('menu', {x: event.clientX, y: event.clientY, kind: pill ? 'tab' : pane ? 'pane' : item ? 'terminal' : icon ? 'workspace' : 'page', id: tab?.id || item?.dataset.terminal || icon?.dataset.workspace || '',
      selection: !!(pane && tab?.term.hasSelection()), exited: !!tab?.exited, settings: active === 'settings', tabs: terminal?.tabs.length || 0, terminals: terminal?.workspace.terminals.length || 0, workspaces: workspaces.size});
  });
  // A middle click closes what it is on: a tab, a terminal or a workspace, and on the workspaces' × every workspace.
  // What is pressed and what is let go must be the same thing, named here by its identifier.
  const closable = target => (node => node && (node.dataset.id || node.dataset.terminal || node.dataset.workspace || 'all'))(target.closest('.tab, [data-terminal], [data-workspace], .workspace.close'));
  let pressed = null;
  document.addEventListener('mousedown', event => { if (event.button === 1) { pressed = closable(event.target); if (pressed) event.preventDefault(); } });
  document.addEventListener('mouseup', event => {
    if (event.button !== 1) return;
    const id = closable(event.target) === pressed ? pressed : null; pressed = null;
    if (id === 'all') closeTabs([...tabs.keys()]); else if (tabs.has(id)) closeTab(id); else if (terminals.has(id)) closeTerminal(id); else if (id) closeWorkspace(id);
  });
  document.addEventListener('keydown', event => {
    if (event.key === 'Escape' && active === 'settings') { event.preventDefault(); closeSettings(); }
    // ⌘1–9 picks a terminal in this workspace; with Option it picks a workspace.
    if (event.metaKey && /^Digit[1-9]$/.test(event.code)) {
      event.preventDefault();
      const index = Number(event.code.slice(5)) - 1, workspace = workspaces.get(current);
      activate(lastTab(event.altKey ? [...workspaces.values()][index] : terminals.get(workspace?.terminals[index])));
    }
    if (event.ctrlKey && event.key === 'Tab') {
      event.preventDefault();
      const terminal = tabs.get(active)?.terminal || terminals.get(workspaces.get(current)?.last), ids = terminal?.tabs || [], index = ids.indexOf(active);
      if (terminal) activate(index < 0 ? terminal.last : ids[(index + (event.shiftKey ? ids.length - 1 : 1)) % ids.length]);
    }
  });
  new ResizeObserver(() => { if (tabs.has(active)) fitTab(tabs.get(active)); }).observe($('stage'));
  dark.addEventListener('change', retheme);
  // A canvas keeps a picture of each character it has drawn, so those made before the symbols font arrived are drawn again.
  document.fonts.load("14px 'cmux2 Symbols'").then(() => { for (const tab of tabs.values()) tab.term.clearTextureAtlas(); });
  // Read-only diagnostics used by the native integration check. `spill` is how far the screen on stage reaches past the room its card leaves it, to the right and below; `scroll` is how far it is scrolled sideways, and `atEnd` whether it shows its last rows.
  window.cmuxDiagnostics = () => ({count: tabs.size, workspaces: [...workspaces.values()].map(w => ({id: w.id, name: w.name, terminals: w.terminals.map(id => terminals.get(id).tabs.length)})), presets: presets.length, theme: document.documentElement.dataset.theme, symbols: document.fonts.check("14px 'cmux2 Symbols'", ''), active, current, sidebarHidden, back: historyIndex > 0, forward: historyIndex < history.length - 1, pill: ['left', 'top', 'width', 'height'].map(edge => parseFloat(getComputedStyle(document.body, '::after')[edge])), titleMiddle: (box => (box.top + box.bottom) / 2)($('breadcrumb').getBoundingClientRect()), folderEnd: $('activity').getBoundingClientRect().right, settingsOpen: active === 'settings', fontSize, lineHeight, icons: document.querySelectorAll('.workspace .icon, .preset .icon').length, atEnd: !tabs.has(active) || atEnd(tabs.get(active)), scroll: tabs.get(active)?.pane.scrollLeft || 0, spill: (tab => { if (!tab) return [0, 0]; const card = tab.pane.getBoundingClientRect(), screen = tab.pane.querySelector('.xterm-screen').getBoundingClientRect(), style = getComputedStyle(tab.pane); return [screen.right - card.right + parseFloat(style.borderRightWidth) + parseFloat(style.paddingRight), screen.bottom - card.bottom + parseFloat(style.borderBottomWidth) + parseFloat(style.paddingBottom)]; })(tabs.get(active)), panes: [...tabs.values()].map(s => ({id: s.id, title: s.title, directory: s.directory, wrap: s.wrap, canvas: !!s.canvas, columns: s.term.cols, rows: s.term.rows, exited: s.exited, text: Array.from({length: s.term.buffer.active.length}, (_, i) => s.term.buffer.active.getLine(i)?.translateToString(true) || '').join('\n')}))});
  post('ready');
})();
